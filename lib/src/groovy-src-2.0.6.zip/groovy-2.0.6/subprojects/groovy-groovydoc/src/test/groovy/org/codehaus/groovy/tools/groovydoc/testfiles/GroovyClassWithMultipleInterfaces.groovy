package org.codehaus.groovy.tools.groovydoc.testfiles

abstract class GroovyClassWithMultipleInterfaces implements GroovyInterface1, JavaInterface1, Runnable {
}
