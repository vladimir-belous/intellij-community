package org.codehaus.groovy.tools.groovydoc.testfiles

public interface GroovyInterfaceWithMultipleInterfaces extends GroovyInterface1, JavaInterface1, Runnable {

}
