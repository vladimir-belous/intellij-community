package org.codehaus.groovy.tools.groovydoc.testfiles

public interface GroovyInterface1 {

}
