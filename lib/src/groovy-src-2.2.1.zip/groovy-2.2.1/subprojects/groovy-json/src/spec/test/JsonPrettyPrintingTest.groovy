class JsonPrettyPrintingTest extends GroovyTestCase {

    void testPrettyPrint() {

    }
}